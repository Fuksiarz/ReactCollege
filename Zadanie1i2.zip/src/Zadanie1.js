import React, {useReducer, useState} from 'react';

function Zadanie1(){

    const [change, setChange]=useReducer((change, number)=>change+number ,0);

    function checkIfPlus(){

        if (change>=1) setChange(-1);


    }

    return (
        <div>
            <button onClick={()=>checkIfPlus()}>-</button>
            <h1>{change}</h1>
            <button onClick={()=>setChange(+1)}>+</button>
        </div>
    );
};

export default Zadanie1;