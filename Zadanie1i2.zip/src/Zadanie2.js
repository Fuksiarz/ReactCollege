import React, {useEffect, useState} from 'react';


function Zadanie2() {

    const [number, setNumber] = useState(0);

    useEffect(() => {
        if (number === 1) alert("End of Collatz!");
    })

    function choose(number) {
        if (number === 1) {
            alert("End of Collatz!")

        }
        number = parseInt(number);
        if (number === 1) {
            setNumber(1);


        } else if (number % 2 === 0) {
            setNumber(number / 2);


        } else if (number % 2 !== 0) {
            setNumber(number * 3 + 1);

        }
        return number;
    }


    return (
        <div>
            <input value={number} type="number" onChange={event => setNumber(event.target.value)}></input>
            <button onClick={() => choose(number)}>Collatz it!</button>
        </div>
    );


}

export default Zadanie2;