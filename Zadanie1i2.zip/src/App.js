import logo from './logo.svg';
import './App.css';
import Zadanie2 from "./Zadanie2";
import Zadanie1 from "./Zadanie1";
import mapa from "./mapa.png";
// App.js
import React, {useEffect, useState, useLayoutEffect} from "react";

function App() {


    return (
        <div>
            <div>
                <div>

                <Zadanie1/>

                </div>
            <div>
                <Zadanie2/>
            </div>
            </div>
        </div>
    );
}

export default App;